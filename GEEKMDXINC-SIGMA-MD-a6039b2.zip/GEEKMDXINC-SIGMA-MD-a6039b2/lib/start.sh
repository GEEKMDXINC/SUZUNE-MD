while true 
do
echo "Starting SIGMA-MD..."
node lib/client.js
done
